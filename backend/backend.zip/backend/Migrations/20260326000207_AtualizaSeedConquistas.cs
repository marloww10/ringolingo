﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Ringolingo.Migrations
{
    /// <inheritdoc />
    public partial class AtualizaSeedConquistas : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "Conquistas",
                keyColumn: "Id",
                keyValue: 1,
                column: "xpGanhado",
                value: 200);

            migrationBuilder.UpdateData(
                table: "Conquistas",
                keyColumn: "Id",
                keyValue: 2,
                columns: new[] { "Descricao", "Titulo", "xpGanhado" },
                values: new object[] { "Acumule 5.000 XP no total", "Acumulador", 300 });

            migrationBuilder.UpdateData(
                table: "Conquistas",
                keyColumn: "Id",
                keyValue: 3,
                columns: new[] { "Descricao", "Titulo", "xpGanhado" },
                values: new object[] { "Use o app por 30 dias consecutivos", "Veterano", 500 });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "Conquistas",
                keyColumn: "Id",
                keyValue: 1,
                column: "xpGanhado",
                value: 100);

            migrationBuilder.UpdateData(
                table: "Conquistas",
                keyColumn: "Id",
                keyValue: 2,
                columns: new[] { "Descricao", "Titulo", "xpGanhado" },
                values: new object[] { "Use o app por 30 dias consecutivos", "Veterano", 500 });

            migrationBuilder.UpdateData(
                table: "Conquistas",
                keyColumn: "Id",
                keyValue: 3,
                columns: new[] { "Descricao", "Titulo", "xpGanhado" },
                values: new object[] { "Acumule 5.000 XP no total", "Acumulador", 300 });
        }
    }
}
