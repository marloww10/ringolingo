﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Ringolingo.Migrations
{
    /// <inheritdoc />
    public partial class AjusteConquistas : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "Conquistas",
                keyColumn: "Id",
                keyValue: 1,
                column: "xpGanhado",
                value: 100);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "Conquistas",
                keyColumn: "Id",
                keyValue: 1,
                column: "xpGanhado",
                value: 200);
        }
    }
}
