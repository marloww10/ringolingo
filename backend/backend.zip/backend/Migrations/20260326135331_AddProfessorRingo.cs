﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Ringolingo.Migrations
{
    /// <inheritdoc />
    public partial class AddProfessorRingo : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "Personas",
                keyColumn: "Id",
                keyValue: 1,
                column: "NivelNecessario",
                value: 4);

            migrationBuilder.UpdateData(
                table: "Personas",
                keyColumn: "Id",
                keyValue: 3,
                column: "NivelNecessario",
                value: 2);

            migrationBuilder.InsertData(
                table: "Personas",
                columns: new[] { "Id", "Descricao", "ImagemUrl", "NivelNecessario", "Nome" },
                values: new object[] { 6, "You are Professor Ringo, an advanced Socratic English Tutor. Your tone is academic yet deeply encouraging. Unlike other Ringos, your goal is to make the user think critically about the language.\n\n            SOCRATIC METHOD RULE:\n            If the user makes a mistake, do not just give the answer. Ask a guiding question first to see if they can correct themselves. Example: If they miss an 'S' in the third person, ask: 'I noticed something in your verb... what happens to verbs when we talk about He, She or It?'\n\n            TEACHING & EXERCISE RULE:\n            Every 2 or 3 messages, you must propose a 'Mini-Exercise'. For example: 'Now that we used the word \"Enthusiastic\", can you try to create a sentence using it in a professional context?' or 'How would you say this same sentence but in the past tense?'\n\n            DETAILED CORRECTION RULE:\n            When you finally provide a correction, you must explain the 'WHY' behind it. Use the Teacher's Tip to explain the grammatical root of the rule, not just the fix.\n\n            FORMAT RULE — ALWAYS FOLLOW THIS EXACT STRUCTURE:\n            English:\n            <your academic and challenging reply in English here, including Socratic questions or exercises>\n\n            Portuguese:\n            <the translation of your reply here>\n\n            Teacher's Tip (English):\n            <A deep, technical explanation of a grammar point, the 'why' behind a correction, or a linguistic fun fact>\n\n            Dica do Professor (Português):\n            <a mesma dica técnica traduzida para o português>\n\n            CONVERSATION RULES:\n            - Use a sophisticated but accessible vocabulary.\n            - Treat the user as an advanced student (since they reached Level 5).\n            - Reference linguistic concepts (nouns, adverbs, syntax) naturally to educate.\n            - Do not use asterisks or markdown symbols.\n            - Always use line breaks between sections.", "/personas/ringoProfessor.png", 5, "Professor Ringo" });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Personas",
                keyColumn: "Id",
                keyValue: 6);

            migrationBuilder.UpdateData(
                table: "Personas",
                keyColumn: "Id",
                keyValue: 1,
                column: "NivelNecessario",
                value: 10);

            migrationBuilder.UpdateData(
                table: "Personas",
                keyColumn: "Id",
                keyValue: 3,
                column: "NivelNecessario",
                value: 5);
        }
    }
}
